﻿namespace CasaDoCodigo
{
    internal interface IDataService
    {
        void InicializaDB();
    }
}